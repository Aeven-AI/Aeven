import { setTimeout as delay } from "node:timers/promises";
import { parseArgs as parseArgv } from "node:util";
import {
  GhGitHubReader,
  WatcherQueryError,
  discoverStack,
  resolveContext,
} from "./github.ts";
import {
  runQueued,
  runSimple,
  statusQueryVerdict,
  verdictFactory,
  type WatchClock,
} from "./policy.ts";
import { renderJson, renderPretty } from "./render.ts";
import type * as T from "./types.ts";
import { nonEmpty, parsePrNumber } from "./types.ts";
/** An option value its parser refuses; the message says what the value must be. */
class InvalidArgumentError extends Error {}
/** Ends argument parsing after help or a usage error was written; `main` maps it to an exit status. */
class UsageExit extends Error {
  readonly exitCode: number;
  constructor(exitCode: number) {
    super(`watch-pr usage exit ${exitCode}`);
    this.exitCode = exitCode;
  }
}
const HELP = `Usage: watch-pr [options]

Watch one pull request, a connected stack, or an immutable queued stack.
JSON (NDJSON while polling) is the default; --pretty renders human text.

Options:
  --owner <owner>             GitHub repository owner
  --repo <repo>               GitHub repository name
  --pr <number>               pull request number
  --stack                     watch the connected open stack (default: false)
  --queued-stack              watch the captured stack until all PRs merge (default: false)
  --stack-prs <n,...>         frozen bottom-to-top queue (queued mode only)
  --interval <seconds>        poll interval (default: 60)
  --sweep-interval <seconds>  whole-stack sweep interval (default: 300)
  --timeout <seconds>         deadline; 0 disables it (default: 0)
  --max-query-errors <count>  consecutive query-error budget (default: 5)
  --status-only               print one status table and exit 0 (default: false)
  --allow-draft               do not treat a draft as a merge gate (default: false)
  --pretty                    render human text instead of JSON (default: false)
  -h, --help                  display help for command
`;
export interface CliOptions {
  readonly owner: string | null;
  readonly repo: string | null;
  readonly pr: T.PrNumber | null;
  readonly mode: T.WatchMode;
  readonly stackPrs: readonly T.PrNumber[];
  readonly statusOnly: boolean;
  readonly pretty: boolean;
  readonly polling: T.PollingOptions;
}
function positiveNumber(value: string): number {
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed <= 0)
    throw new InvalidArgumentError("must be greater than zero");
  return parsed;
}
function nonNegativeNumber(value: string): number {
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < 0)
    throw new InvalidArgumentError("must be zero or greater");
  return parsed;
}
function positiveInteger(value: string): number {
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed <= 0)
    throw new InvalidArgumentError("must be a positive integer");
  return parsed;
}
function prNumber(value: string): T.PrNumber {
  try {
    return parsePrNumber(Number(value.replace(/^#/, "")));
  } catch {
    throw new InvalidArgumentError("must be a positive integer");
  }
}
function stackPrList(value: string): T.NonEmpty<T.PrNumber> {
  const numbers = value.split(",").map((part) => prNumber(part.trim()));
  if (new Set(numbers).size !== numbers.length)
    throw new InvalidArgumentError("contains a duplicate PR");
  const parsed = nonEmpty(numbers);
  if (parsed === null) throw new InvalidArgumentError("cannot be empty");
  return parsed;
}
const OPTIONS = {
  owner: { type: "string" },
  repo: { type: "string" },
  pr: { type: "string" },
  stack: { type: "boolean", default: false },
  "queued-stack": { type: "boolean", default: false },
  "stack-prs": { type: "string" },
  interval: { type: "string" },
  "sweep-interval": { type: "string" },
  timeout: { type: "string" },
  "max-query-errors": { type: "string" },
  "status-only": { type: "boolean", default: false },
  "allow-draft": { type: "boolean", default: false },
  pretty: { type: "boolean", default: false },
  help: { type: "boolean", short: "h", default: false },
} as const;
function readValues(argv: readonly string[]) {
  return parseArgv({ args: [...argv], strict: true, allowPositionals: false, options: OPTIONS }).values;
}
export function parseArgs(
  argv: readonly string[],
  io: Pick<CliRuntime, "stdout" | "stderr">
): CliOptions {
  const fail = (message: string): never => {
    io.stderr(`error: ${message}\n`);
    throw new UsageExit(1);
  };
  let values: ReturnType<typeof readValues>;
  try {
    values = readValues(argv);
  } catch (error) {
    // node:util reports a malformed command line as a TypeError coded ERR_PARSE_ARGS_*.
    const code = (error as { code?: unknown } | null)?.code;
    if (!(error instanceof TypeError) || typeof code !== "string" || !code.startsWith("ERR_PARSE_ARGS"))
      throw error;
    return fail(error.message);
  }
  if (values.help) {
    io.stdout(HELP);
    throw new UsageExit(0);
  }
  const convert = <V>(name: string, raw: string | undefined, parse: (value: string) => V): V | undefined => {
    if (raw === undefined) return undefined;
    try {
      return parse(raw);
    } catch (error) {
      if (!(error instanceof InvalidArgumentError)) throw error;
      return fail(`option '--${name}' argument '${raw}' is invalid. ${error.message}`);
    }
  };
  if (values.stack && values["queued-stack"])
    fail("option '--stack' cannot be used with option '--queued-stack'");
  const stackPrs = convert("stack-prs", values["stack-prs"], stackPrList);
  if (stackPrs !== undefined && !values["queued-stack"])
    fail("--stack-prs requires --queued-stack");
  return {
    owner: values.owner ?? null,
    repo: values.repo ?? null,
    pr: convert("pr", values.pr, prNumber) ?? null,
    mode: values["queued-stack"] ? "queued-stack" : values.stack ? "stack" : "single",
    stackPrs: stackPrs ?? [],
    statusOnly: values["status-only"],
    pretty: values.pretty,
    polling: {
      interval: convert("interval", values.interval, positiveNumber) ?? 60,
      sweepInterval: convert("sweep-interval", values["sweep-interval"], positiveNumber) ?? 300,
      timeout: convert("timeout", values.timeout, nonNegativeNumber) ?? 0,
      maxQueryErrors: convert("max-query-errors", values["max-query-errors"], positiveInteger) ?? 5,
      allowDraft: values["allow-draft"],
    },
  };
}
export interface CliRuntime {
  readonly reader: T.GitHubReader;
  readonly clock: WatchClock;
  readonly stdout: (value: string) => void;
  readonly stderr: (value: string) => void;
}
function realRuntime(): CliRuntime {
  return {
    reader: new GhGitHubReader(),
    clock: {
      now: () => performance.now() / 1_000,
      observedAt: () => new Date().toISOString(),
      sleep: async (seconds) => {
        await delay(seconds * 1_000);
      },
    },
    stdout: (value) => process.stdout.write(value),
    stderr: (value) => process.stderr.write(value),
  };
}
export async function main(
  argv: readonly string[],
  runtime: CliRuntime = realRuntime()
): Promise<number> {
  let options: CliOptions;
  try {
    options = parseArgs(argv, runtime);
  } catch (error) {
    if (!(error instanceof UsageExit)) throw error;
    return error.exitCode === 0 ? 0 : 64;
  }
  const render = options.pretty ? renderPretty : renderJson;
  const emit = (verdict: T.ProgressVerdict): void =>
    runtime.stdout(render(verdict));
  let contexts: T.NonEmpty<T.PrContext>;
  try {
    const seed = await resolveContext({
      reader: runtime.reader,
      owner: options.owner,
      repo: options.repo,
      pr: options.pr ?? options.stackPrs[0] ?? null,
    });
    contexts =
      nonEmpty(options.stackPrs.map((number) => ({ ...seed, number }))) ??
      (options.mode === "single"
        ? [seed]
        : await discoverStack(runtime.reader, seed));
  } catch (error) {
    if (!(error instanceof WatcherQueryError)) throw error;
    const verdict = statusQueryVerdict(
      verdictFactory(runtime.clock, options.mode),
      1,
      error.failure
    );
    runtime.stdout(render(verdict));
    return verdict.exitCode;
  }
  const dependencies = { reader: runtime.reader, clock: runtime.clock, emit };
  const verdict =
    options.mode === "queued-stack" && !options.statusOnly
      ? await runQueued({ dependencies, contexts, options: options.polling })
      : await runSimple({
          dependencies,
          contexts,
          mode: options.mode,
          statusOnly: options.statusOnly,
          options: options.polling,
        });
  runtime.stdout(render(verdict));
  return verdict.exitCode;
}
